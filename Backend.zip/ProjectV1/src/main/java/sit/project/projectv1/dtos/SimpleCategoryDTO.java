package sit.project.projectv1.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SimpleCategoryDTO {
    private Integer categoryId;
    private String categoryName;

    public String getCategoryName() {
        return categoryName;
    }
}
