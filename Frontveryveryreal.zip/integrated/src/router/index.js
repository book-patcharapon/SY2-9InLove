import { createRouter, createWebHistory } from 'vue-router'
import Announcement from '../components/Announcement.vue'
import AnnouncementView from '../components/AnnouncementView.vue'

const router = createRouter(
    {
    history:createWebHistory(),
    routes:
    [
        {
            path:'/',
            redirect:'/announcement'
        },
        {
        path:'/announcement',
        name:'Announcement',
        component: Announcement
        },
        {
        path:'/announcementView/:annId',
        name:'AnnouncementView',
        component:AnnouncementView
        }
    ]}
    )

export default router