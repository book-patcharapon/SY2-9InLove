const getAnnouncement = async () => {
    try {
        const res = await fetch('http://localhost:8080/api/announcements')
        if(res.ok) {
          const Announcement = await res.json()
          console.log(Announcement);
          return Announcement
        } else {
          throw new Error(`No Announcement`)
        }
      } catch (error) {
        alert(`ERROR: can't read data, ${error}`)
        console.log(`ERROR: can't read data, ${error}`)
      }
}

// const getInformation= (id) => {
//   return  fetch(`http://localhost:5000/Announcement/${id}`)
//       .then(resp => resp.json())
//       .catch(error => `ERROR cannot read data: ${error}`);
//}

export { getAnnouncement}