const getInformation = async (id) => {
    try {
        const res = await fetch(`http://localhost:8080/api/announcements/${id}`)
        if(res.ok) {
          const Announcement = await res.json()
          console.log(Announcement);
          return Announcement
        } else {
          throw new Error(`No Announcement`)
        }
      } catch (error) {
        alert(`ERROR: can't read data, ${error}`)
        console.log(`ERROR: can't read data, ${error}`)
      }
}
export { getInformation}