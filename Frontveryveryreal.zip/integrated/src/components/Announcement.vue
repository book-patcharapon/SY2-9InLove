<script setup>
import { ref, onMounted } from "vue"
import { getAnnouncement} from "../composable/getAnnouncement.js"
// import AnnouncementView from "./AnnouncementView.vue";

const announcement = ref([])



onMounted(async () => {
    announcement.value = await getAnnouncement()
})
</script>
 
<template>
    <!-- <AnnouncementView :currentAnn="currentAnn"/> -->
<table>

    <tr>
        <th>No.</th>
        <th>Title</th>
        <th>Category</th>
        <th>Publish Date</th>
        <th>close date</th>
        <th>Display</th>
        <th>Action</th>
    </tr>

    <tr v-for="ann in announcement" :key="ann.announcementID">
        <td> {{ ann.announcementID }}</td>
        <td>{{ ann.announcementTitle }}</td>
        <td>{{ ann.categoryName }}</td>
        <td>{{ ann.publishDate }}</td>
        <td>{{ ann.closeDate }}</td>
        <td>{{ ann.announcementDisplay }}</td>
        <td> <RouterLink :to="{ name: 'AnnouncementView',params:{annId: ann.announcementID} }" >view</RouterLink></td>
       
    </tr>

</table>
<div v-if="announcement.length === 0">No Announcement</div>
</template>
 
<style scoped>

</style>