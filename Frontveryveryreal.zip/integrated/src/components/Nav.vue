<script setup>
import { RouterLink } from "vue-router";
</script>
 
<template>
    <div class="w-full">

      <RouterLink :to="{ name: 'Announcement' }">Announcement</RouterLink>

  </div>
</template>
 
<style scoped>

</style>