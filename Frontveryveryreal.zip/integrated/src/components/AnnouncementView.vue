<script setup>
import { ref, onMounted } from 'vue'
import { getInformation } from '../composable/getAnnouncementbyId.js'
import {useRoute} from 'vue-router'

const information = ref([])

onMounted(async () => {
    information.value = await getInformation(params.annId)

})
const { params } = useRoute()
console.log(params.annId)
</script>
 
<template>
<div>
<h1>Announcement Detail:</h1>
title: {{ information.announcementTitle }} <br>
category: {{ information.categoryName }} <br>
description: {{ information.announcementDescription }} <br>
publishDate: {{ information.publishDate }} <br>
closeDate: {{ information.closeDate }} <br>
display: {{ information.announcementDisplay }} <br>
<RouterLink :to="{ name: 'Announcement' }">back</RouterLink>
</div>
</template>
 
<style scoped>

</style>