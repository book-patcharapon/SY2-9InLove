<script setup>
import { ref, onMounted } from "vue"
import { getAnnouncement } from "../composable/getAnnouncement.js"
import { changeDateTimeFormat } from "../composable/changeDateTimeFormat.js"

const announcements = ref([])
const time = Intl.DateTimeFormat().resolvedOptions().timeZone

onMounted(async () => {
    announcements.value = await getAnnouncement()
})
</script>
 
<template>
    <div class="w-full">
        <h1>SIT Announcement System (SAS)</h1>
        <div v-if="announcements.length === 0">No Announcement</div>

        <div v-else class="relative overflow-x-auto">
            <p>Date/Time Shown in Timezone: {{ time }}</p>
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th>No.</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Publish Date</th>
                        <th>Close date</th>
                        <th>Display</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <tr v-for="(ann, index) in announcements" :key="index"
                        class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <td>{{ ann.id }}</td>
                        <td>{{ ann.announcementTitle }}</td>
                        <td>{{ ann.categoryName }}</td>
                        <td>{{ changeDateTimeFormat(ann.publishDate) }}</td>
                        <td>{{ changeDateTimeFormat(ann.closeDate) }}</td>
                        <td>{{ ann.announcementDisplay }}</td>
                        <td>
                            <RouterLink :to="{ name: 'AnnouncementView', params: { id: ann.id } }">
                                <button>
                                    View
                                </button>
                            </RouterLink>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
 
<style scoped></style>