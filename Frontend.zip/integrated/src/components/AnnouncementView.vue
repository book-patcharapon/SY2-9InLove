<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { changeDateTimeFormat } from '../composable/changeDateTimeFormat.js'
import { getInformation } from '../composable/getAnnouncementbyId.js';

const information = ref([])
const { params } = useRoute()

onMounted(async () => {
    information.value = await getInformation(params.id)
})
</script>
 
<template>
    <div class="w-full">
        <div>
            <h1>Announcement Detail:</h1>
            <p>Title: {{ information.announcementTitle }}</p>
            <p>Category: {{ information.categoryname }}</p>
            <p>Description: {{ information.announcementDescription }}</p>
            <p>PublishDate: {{ changeDateTimeFormat(information.publishDate) }}</p>
            <p>CloseDate: {{ changeDateTimeFormat(information.closeDate) }}</p>
            <p>Display: {{ information.announcementDisplay }}</p>
            <RouterLink :to="{ name: 'Announcement' }">
                <button>
                    Back
                </button>
            </RouterLink>
        </div>
    </div>
</template>
 
<style scoped></style>