const getInformation = async (id) => {
    try {
        const res = await fetch(`http://localhost:8080/api/announcements/${id}`)
        if(res.ok) {
          const Announcement = await res.json()
          return Announcement
        } else {
          throw new Error(`No Announcement`)
        }
      } catch (error) {
        console.log(`ERROR: can't read data, ${error}`)
      }
}

export { getInformation }