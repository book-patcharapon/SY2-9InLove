package sit.project.projectv1.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sit.project.projectv1.dtos.AnnouncementDetailDTO;
import sit.project.projectv1.dtos.SimpleAnnouncementDTO;
import sit.project.projectv1.entities.Announcement;
import sit.project.projectv1.services.AnnouncementService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
@RequestMapping("/api/announcements")
public class AnnouncementController {
    @Autowired
    private AnnouncementService announcementService;
    @Autowired
    private ModelMapper modelMapper;

//    @GetMapping
//    public List<Announcement> getAllAnnouncement() {
//        return announcementService.getAllAnnouncement();
//    }

    @GetMapping
    public List<SimpleAnnouncementDTO> getAllAnnouncementDTO() {
        List<Announcement> announcementList = announcementService.getAllAnnouncement();
        List<SimpleAnnouncementDTO> simpleAnnouncementDTOS = announcementList.stream()
                .map(announcement -> modelMapper.map(announcement, SimpleAnnouncementDTO.class))
                .collect(Collectors.toList());
        return simpleAnnouncementDTOS;
    }

    @GetMapping("{announcementId}")
    public AnnouncementDetailDTO getAnnouncementById(@PathVariable Integer announcementId) {
        return modelMapper.map(announcementService.getAnnouncementById(announcementId), AnnouncementDetailDTO.class);
//        return announcementService.getAnnouncement(announcementId);
    }
}
