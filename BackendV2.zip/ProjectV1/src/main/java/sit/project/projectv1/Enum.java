package sit.project.projectv1;

public enum Enum {
    Y, N
}
