package sit.project.projectv1.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import sit.project.projectv1.Enum;

import java.time.ZonedDateTime;

@Getter
@Setter
@Entity
@Table(name = "announcement")
public class Announcement {
    @Id
    @Column(name = "announcementID")
    private Integer id;
    private String announcementTitle;
    private String announcementDescription;
    private ZonedDateTime publishDate;
    private ZonedDateTime closeDate;

    @Enumerated(EnumType.STRING)
    private Enum announcementDisplay;

    @ManyToOne
    @JoinColumn(name = "categoryId")
    private Category announcementCategory;
}
