<script setup>
import { RouterView } from 'vue-router'
</script>
 
<template>
    <div class="w-full">
        <!-- <Nav  /> -->
        <RouterView />
    </div>
</template>
 
<style scoped></style>