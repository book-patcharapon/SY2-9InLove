<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { changeDateTimeFormat } from '../composable/changeDateTimeFormat.js'
import { getInformation, announcement } from '../composable/getAnnouncementbyId.js'

const haveInfo = ref()
const { params } = useRoute()

onMounted(async () => {
    await getInformation(params.id)
    if (announcement) {
        haveInfo.value = true
    }
})
</script>
 
<template>
    <div class="w-full">
        <div v-if="haveInfo">
            <h1 class="text-4xl font-bold">Announcement Detail:</h1>
            <p><b>Title:</b> {{ announcement.announcementTitle }}</p>
            <p><b>Category:</b> {{ announcement.announcementCategory }}</p>
            <p><b>Description:</b> {{ announcement.announcementDescription }}</p>
            <p><b>PublishDate:</b> {{ changeDateTimeFormat(announcement.publishDate) }}</p>
            <p><b>CloseDate:</b> {{ changeDateTimeFormat(announcement.closeDate) }}</p>
            <p><b>Display:</b> {{ announcement.announcementDisplay }}</p>
            <RouterLink :to="{ name: 'Announcement' }">
                <button>
                    Back
                </button>
            </RouterLink>
        </div>
        <div v-else>
            <h1>No Announcement Found!!!</h1>
        </div>
    </div>
</template>
 
<style scoped>
button {
    border: 2px solid black;
    background-color: lightgrey;
    color: black;
    font-weight: bold;
    padding: 2px;
}
</style>