<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { changeDateTimeFormat } from '../composable/changeDateTimeFormat.js'
import { getInformation, announcement } from '../composable/getAnnouncementbyId.js'

const haveInfo = ref()
const { params } = useRoute()

onMounted(async () => {
    await getInformation(params.id)
    if (announcement) {
        haveInfo.value = true
    }
})
</script>
 
<template>
    <div class="w-full centerr">
        <div v-if="haveInfo" class=" p-4">
            <h1 class="text-4xl p-4">Announcement Detail:</h1>
        <div class="border-4 p-8">
            <p><b>Title:</b> {{ announcement.announcementTitle }}</p>
            <p><b>Category:</b> {{ announcement.announcementCategory }}</p>
            <p><b>Description:</b> {{ announcement.announcementDescription }}</p>
            <p><b>PublishDate:</b> {{ changeDateTimeFormat(announcement.publishDate) }}</p>
            <p><b>CloseDate:</b> {{ changeDateTimeFormat(announcement.closeDate) }}</p>
            <p><b>Display:</b> {{ announcement.announcementDisplay }}</p>
        </div>
        <RouterLink :to="{ name: 'Announcement' }">
                <button  class="my-2">
                    Back
                </button>
            </RouterLink>
        </div>
        <div v-else>
            <h1>No Announcement Found!!!</h1>
        </div>
    </div>
</template>
 
<style scoped>
button {
    border: 2px solid black;
    background-color: lightgrey;
    color: black;
    font-weight: bold;
    padding: 5px;
}

.centerr {
    display : flex ;
    justify-content: center;
}

</style>