import { ref } from "vue"
import router from "../router"

const announcement = ref([])

const getInformation = async (id) => {
  try {
    const res = await fetch(`http://localhost:8080/api/announcements/${id}`)
    if (res.ok) {
      announcement.value = await res.json()
      return announcement.value
    } else {
      alert(`The request page is not available.`)
      router.push("/admin/announcement");
      throw new Error(`No Announcement`)
      
    }
  } catch (error) {
    console.log(`ERROR: can't read data, ${error}`)
  }
};

export { getInformation, announcement }
