const allannouncement = ref()

const getAnnouncement = async () => {
  try {
    const res = await fetch("http://localhost:8080/api/announcements")
    if (res.ok) {
      allannouncement.value = await res.json()
      return allannouncement.value
    } else {
      throw new Error(`No Announcement`)
    }
  } catch (error) {
    console.log(`ERROR: can't read data, ${error}`)
  }
}

// const getInformation= (id) => {
//   return  fetch(`http://localhost:5000/Announcement/${id}`)
//       .then(resp => resp.json())
//       .catch(error => `ERROR cannot read data: ${error}`);
//}

export { getAnnouncement }
