const options = {
    // day: 'numeric',
    // month: 'short',
    // year: 'numeric',
    // hour: 'numeric',
    // minute: 'numeric',
    // timeZone: 'Asia/Bangkok',
    // hour12: false
    dateStyle: 'medium',
    timeStyle: 'short'
}

const changeDateTimeFormat = (date) => {
    const dateTime = new Date(date)
    if(dateTime.getFullYear() > 1970) {
        return dateTime.toLocaleString("en-GB", options)
    }
}

export { changeDateTimeFormat }