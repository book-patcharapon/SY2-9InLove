<script setup>
import { ref, onMounted, onBeforeMount } from 'vue'
import { useRoute } from 'vue-router'
import { changeDateTimeFormat } from '../composable/changeDateTimeFormat.js'
import { getInformation, announcement } from '../composable/getAnnouncementbyId.js'

const information = ref([])
const haveInfo = ref()
const { params } = useRoute()

onMounted(async () => {
    await getInformation(params.id)
    if (announcement) {
        haveInfo.value = true
    }
})
</script>
 
<template>
    <div class="w-full">
        <div v-if="haveInfo">
            <h1>Announcement Detail:</h1>
            <p>Title: {{ information.announcementTitle }}</p>
            <p>Category: {{ information.announcementCategory }}</p>
            <p>Description: {{ information.announcementDescription }}</p>
            <p>PublishDate: {{ changeDateTimeFormat(information.publishDate) }}</p>
            <p>CloseDate: {{ changeDateTimeFormat(information.closeDate) }}</p>
            <p>Display: {{ information.announcementDisplay }}</p>
            <RouterLink :to="{ name: 'Announcement' }">
                <button>
                    Back
                </button>
            </RouterLink>
        </div>
        <div v-else>
            <h1>No Announcement Found!!!</h1>
        </div>
    </div>
</template>
 
<style scoped></style>